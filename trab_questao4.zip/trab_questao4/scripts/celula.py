class Celula:
    def __init__(self, eixo_x, eixo_y):
        self.obstaculo=None #indica se há obstaculo nesta celula
        self.distancia_para_alvo=None
        self.coord_y=None #coordenada y da célula
        self.coord_x=None #coordenada x da célula