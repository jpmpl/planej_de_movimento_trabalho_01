#! /usr/bin/env python3
import cv2
import numpy as np
from nav_msgs.msg import *
from sensor_msgs.msg import *
import rospy
from geometry_msgs.msg import Twist  # tópico cmd_vel
import time
import sys
from math import atan2, sqrt, cos, sin
from celula import Celula  # carrega estrutura de dados criada para celula
from tf.transformations import euler_from_quaternion

# global matriz
global matriz_celula  # matriz 30x30 do mapa. Cada celula possui 4 atributos
global matriz_indica_obstaculos  # esta matriz vai indicar se há obstaculo na celula
global matriz_caminho  # essa matriz 2x100 irá conter o caminho até chegar ao alvo
global primeira_vez
primeira_vez = 0
# _____________________________________________________________________________________________________________________
#                                       Definições                                                                    #
# ______________________________________________________________________________________________________________________

# Abaixo definimos a variavel laser do tipo LaserScan. Ela será usada para
# pegarmos os dados da função laser_callback() e usarmos dentro da função
# principal
laser = LaserScan()

# Abaixo definimos a variavel odometry do tipo Odometry. Ela será usada
# para pegarmos os dados da função odometry_callback() e usarmos dentro da
# função principal
odometry = Odometry()


# Cria uma função para receber os dados lidos de /odom. Os dados vem
# na variavel data
def odometry_callback(data):
    global odometry  # definimos como variavel global
    odometry = data  # pegamos o que chega em data e colocamos na variavel odometry


# Cria uma função para receber os dados lidos de /base_scan. Os dados vem
# na variavel data
def laser_callback(data):
    global laser  # definimos como variavel global
    laser = data  # pegamos o que chega em data e colocamos em laser


def preenche_a_direita(coluna_y, linha_x):  # esta função irá preencher a distancia para o alvo das celulas a direita
    while matriz_celula[coluna_y][linha_x].obstaculo == 0 and linha_x < 29 and matriz_celula[coluna_y][
        linha_x].distancia_para_alvo != None:
        if matriz_celula[coluna_y][linha_x + 1].obstaculo == 0:
            matriz_celula[coluna_y][linha_x + 1].distancia_para_alvo = matriz_celula[coluna_y][
                                                                           linha_x].distancia_para_alvo + 1
            linha_x += 1
        else:
            linha_x = 29


def preenche_a_esquerda(coluna_y, linha_x):  # esta função irá preencher a distancia para o alvo das celulas a esquerda
    while matriz_celula[coluna_y][linha_x].obstaculo == 0 and linha_x > 0 and matriz_celula[coluna_y][
        linha_x].distancia_para_alvo != None:
        if matriz_celula[coluna_y][linha_x - 1].obstaculo == 0:
            matriz_celula[coluna_y][linha_x - 1].distancia_para_alvo = matriz_celula[coluna_y][
                                                                           linha_x].distancia_para_alvo + 1
            linha_x -= 1
        else:
            linha_x = 0


def preenche_acima(coluna_y, linha_x):  # esta função irá preencher a distancia para o alvo das celulas acima
    while matriz_celula[coluna_y][linha_x].obstaculo == 0 and coluna_y > 0 and matriz_celula[coluna_y][
        linha_x].distancia_para_alvo != None:
        if matriz_celula[coluna_y - 1][linha_x].obstaculo == 0:
            matriz_celula[coluna_y - 1][linha_x].distancia_para_alvo = matriz_celula[coluna_y][
                                                                           linha_x].distancia_para_alvo + 1
            coluna_y -= 1
        else:
            coluna_y = 0


def preenche_abaixo(coluna_y, linha_x):  # esta função irá preencher a distancia para o alvo das celulas a esquerda
    while matriz_celula[coluna_y][linha_x].obstaculo == 0 and coluna_y < 29 and matriz_celula[coluna_y][
        linha_x].distancia_para_alvo != None:
        if matriz_celula[coluna_y + 1][linha_x].obstaculo == 0:
            matriz_celula[coluna_y + 1][linha_x].distancia_para_alvo = matriz_celula[coluna_y][
                                                                           linha_x].distancia_para_alvo + 1
            coluna_y += 1
        else:
            coluna_y = 29


def busca_celula_peso_esquerda(coluna_y, linha_x):  # esta função busca a primeira celula com peso a esquerda
    dist = 0
    achou = 0
    if linha_x != 0:  # se linha_x==0 nao faz sentido procurar celulas a esquerda
        while matriz_celula[coluna_y][linha_x].distancia_para_alvo == None and linha_x > 0 and matriz_celula[coluna_y][
            linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].distancia_para_alvo == None:
                dist += 1
            linha_x -= 1
        if matriz_celula[coluna_y][
            linha_x].distancia_para_alvo != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x


def busca_celula_peso_direita(coluna_y, linha_x):  # esta função busca a primeira celula com peso a direita
    dist = 0
    achou = 0
    if linha_x != 29:  # se linha_x==29 nao faz sentido procurar celulas a direita
        while matriz_celula[coluna_y][linha_x].distancia_para_alvo == None and linha_x <= 29 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].distancia_para_alvo == None:
                dist += 1
            linha_x += 1
        if matriz_celula[coluna_y][
            linha_x].distancia_para_alvo != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x


def busca_celula_peso_acima(coluna_y, linha_x):  # esta função busca a primeira celula com peso, acima
    dist = 0
    achou = 0
    if coluna_y != 0:  # se coluna_y==0 nao faz sentido procurar celulas acima
        while matriz_celula[coluna_y][linha_x].distancia_para_alvo == None and coluna_y >= 0 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].distancia_para_alvo == None:
                dist += 1
            coluna_y -= 1
        if matriz_celula[coluna_y][
            linha_x].distancia_para_alvo != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x


def busca_celula_peso_abaixo(coluna_y, linha_x):  # esta função busca a primeira celula com peso, abaixo
    dist = 0
    achou = 0
    if coluna_y != 29:  # se coluna_y==29 nao faz sentido procurar celulas abaixo
        while matriz_celula[coluna_y][linha_x].distancia_para_alvo == None and coluna_y <= 29 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].distancia_para_alvo == None:
                dist += 1
            coluna_y += 1
        if matriz_celula[coluna_y][
            linha_x].distancia_para_alvo != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x


def showImage(img):
    from matplotlib import pyplot as plt
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    plt.imshow(img)
    plt.show()


def crie_matriz_celula(n_linhas, n_colunas):  # cria uma matriz de objetos
    # Vamos criar uma matriz
    mat = []  # matriz vazia
    # Primeiro cria a linha
    for i in range(n_linhas):
        linha = []  # linha vazia, elementos
        for j in range(n_colunas):
            teste = Celula(i, j)
            linha.append(teste)  # adiciona o valor 0 na celula
        mat.append(linha)
    return mat


def crie_matriz(n_linhas, n_colunas):  # cria uma matriz de objetos #cria matriz generica
    # Vamos criar uma matriz
    mat = []  # matriz vazia
    # Primeiro cria a linha
    for i in range(n_linhas):
        linha = []  # linha vazia, elementos
        for j in range(n_colunas):
            linha.append(0)  # adiciona o valor 0 na celula
        mat.append(linha)
    return mat


def calcula_coord_pixel(coord_pixel_y, coord_pixel_x):
    aux1_x = 0
    while aux1_x <= 29:
        aux1_y = 0
        while aux1_y <= 29:
            if (matriz_celula[aux1_y][aux1_x].coord_x - 10) <= (coord_pixel_x) and (coord_pixel_x) <= (
                    matriz_celula[aux1_y][aux1_x].coord_x + 9):
                if (matriz_celula[aux1_y][aux1_x].coord_y - 10) <= (coord_pixel_y) and (coord_pixel_y) <= (
                        matriz_celula[aux1_y][aux1_x].coord_y + 9):
                    print('Indices da celula destino (x,y): (', aux1_x, ',', aux1_y, ')')
                    return aux1_y, aux1_x
            aux1_y += 1
        aux1_x += 1


# A função abaixo definirá para onde o robo deve caminhar. Os indices iy e ix são da célula onde o robo se encontra
def celula_destino(iy, ix):
    # print('Indice x: ', ix, 'Indice y: ', iy)
    ix_parcial = ix
    iy_parcial = iy
    # Trabalha a celula superior e a da esquerda
    if matriz_celula[iy - 1][ix].obstaculo != 0 and matriz_celula[iy][
        ix - 1].obstaculo == 0:  # se a celula superior for obstaculo
        ix_parcial = ix - 1
        iy_parcial = iy
    elif matriz_celula[iy][ix - 1].obstaculo != 0 and matriz_celula[iy - 1][
        ix].obstaculo == 0:  # se a celula da esquerda for obstaculo
        ix_parcial = ix
        iy_parcial = iy - 1

    if matriz_celula[iy - 1][ix].obstaculo == 0 and matriz_celula[iy][
        ix - 1].obstaculo == 0:  # as celulas superior e a da esquerda sao livres
        if matriz_celula[iy - 1][ix].distancia_para_alvo <= matriz_celula[iy][ix - 1].distancia_para_alvo:
            ix_parcial = ix
            iy_parcial = iy - 1
        else:
            ix_parcial = ix - 1
            iy_parcial = iy

    # Ate aqui ix_parcial e iy_parcial indicam o resultado da comparaçao entre a celula superior e a da esquerda

    # Agora vamos comparar o resultado anterior com a celula inferior
    if matriz_celula[iy + 1][ix].obstaculo == 0:  # se a celula inferior for obstaculo nao preciso comparar
        if matriz_celula[iy + 1][ix].distancia_para_alvo <= matriz_celula[iy_parcial][ix_parcial].distancia_para_alvo:
            ix_parcial = ix
            iy_parcial = iy + 1

    # Agora vamos comparar o resultado anterior com a celula da direita
    if matriz_celula[iy][ix + 1].obstaculo == 0:  # se a celula da direta for obstaculo nao preciso comparar
        if matriz_celula[iy][ix + 1].distancia_para_alvo < matriz_celula[iy_parcial][ix_parcial].distancia_para_alvo:
            ix_parcial = ix + 1
            iy_parcial = iy

    return (iy_parcial, ix_parcial)


def odometry_callback_robot(data):
    global q0, theta, k, d, x0, y0
    orient = data.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion([orient.x, orient.y, orient.z, orient.w])
    x0 = data.pose.pose.position.x + d * cos(theta)
    y0 = data.pose.pose.position.y + d * sin(theta)
    q0 = np.array([x0, y0])


# _____________________________________________________________________________________________________________________
#                                       Fim da Definições                                                            #
# ______________________________________________________________________________________________________________________


obj_img: None = cv2.imread("/home/eudes/catkin_ws/src/trab_questao4/worlds/cenario.pgm")
altura, largura, canais_de_cor = obj_img.shape  # retorna largura, altura e canais de cor do map

# ========================================Iniciaremos o preenchimento da matriz célula=================================

# -------------------------------Inicia a identificação de obstaculo na celula-----------------------------------------
#####Inicia a definição de cada célula
##A celula sera uma matriz de 60x60 pixels
matriz_celula = crie_matriz_celula(30, 30)  # cria a matriz com cada celula
aux1_x = 0
indice_x = 0  # indice x da matriz celula maior 30x30
while aux1_x < 600:  # percorre as colunas
    aux1_y = 0
    indice_y = 0  # indice y  da matriz celula maior 30x30
    while aux1_y < 600:  # percorre as linhas
        tem_obstaculo = 0
        x = aux1_x

        while x < aux1_x + 20:
            y = aux1_y
            while y < aux1_y + 20:
                r, g, b = obj_img[y][x]  # retorna RGB
                if r != 255 or g != 255 or b != 255:  # se o pixel não for branco tem_obstaculo=1
                    tem_obstaculo = 1
                    #y = aux1_y + 20  # caso tenha achado algum pixel diferente de branco pula para próxima celula
                    #x = aux1_x + 20  # caso tenha achado algum pixel diferente de branco pula para próxima celula
                y += 1
            x += 1

        if tem_obstaculo == 0:
            matriz_celula[indice_y][indice_x].obstaculo = 0  # grava 0 caso não tenha obstaculo na celula
        if tem_obstaculo == 1:
            matriz_celula[indice_y][indice_x].obstaculo = 1  # grava 1 caso tenha obstaculo na celula

        indice_y += 1
        aux1_y = aux1_y + 20
    indice_x += 1
    aux1_x = aux1_x + 20

# -----------------------------------Fim da procura por obstáculo nas células ------------------------------------------

####################################Início da colocação das coordenadas das celulas ###################################

aux1_x = 0
while aux1_x < 30:
    aux1_y = 0
    while aux1_y < 30:
        matriz_celula[aux1_y][aux1_x].coord_x = aux1_x * 20 + 10  # calcula a coordenada x (em pixel)
        matriz_celula[aux1_y][aux1_x].coord_y = aux1_y * 20 + 10  # calcula a coordenada y (em pixel)
        aux1_y += 1
    aux1_x += 1

# --------------------------------------Fim do cálculo das coordenadas das células -------------------------------------

if sys.version_info.major == 2:  # Entrada das coordenadas do destino
    #xcoor, ycoor = raw_input('Digite o centro (x,y) do ponto onde se deseja chegar: ').split()
    xcoor=250
    ycoor=250
elif sys.version_info.major == 3:
    #xcoor, ycoor = input('Digite o centro (x,y) do ponto onde se deseja chegar: ').split()
    xcoor = 250
    ycoor = 250
    cx = float(xcoor)  # transforma em float
    cy = float(ycoor)  # transforma em float

# --------------------------------------Agora temos que calcular em qual célula está o destino -------------------------
print()  # quebra de linha
print('Calculando a coordenada do destino...')
# Calculando a coordenada em pixel
coord_pixel_x = cx + 300  # coordenada x em pixel
coord_pixel_y = -cy + 300  # coordenada y em pixel
c_dest_celula_y, c_dest_celula_x = calcula_coord_pixel(coord_pixel_y,
                                                       coord_pixel_x)  # retorna os indices da matriz_celula onde está o destino

# -----------Fim da procura de qual coordenada na matriz de celula está o destino --------------------------------------

# ----------Verifica se a coordenada digitada está em cima de um obstáculo ---------------------------------------------
print('Verificando se a coordenada do destino se encontra sobre um obstáculo ...')
if matriz_celula[c_dest_celula_y][c_dest_celula_x].obstaculo == 1:
    destino_no_obstaculo = 1  # indica que o destino está em cima de um obstáculo se = 1
elif matriz_celula[c_dest_celula_y][c_dest_celula_x].obstaculo == 0:
    destino_no_obstaculo = 0

# -----------Caso o destino esteja em cima de um obstaculo, desloco a celula destino para a proxima livre acima --------
if destino_no_obstaculo == 1:
    print('Realocando o destino para uma célula livre ...')
    y = c_dest_celula_y - 1  # caso esteja no obstaculo recebe o valor da celula acima
    achou = 0  # flag para indicar que achou celula livre acima (achou=1)
    while y >= 0:
        if matriz_celula[y][c_dest_celula_x].obstaculo == 0:
            c_dest_celula_y = y
            achou = 1
            y = -1  # sai do loop caso tenha achado celula livre
        y = y - 1
    if achou == 0:
        print("Erro: Coordenada sobre obstaculo e sem possibilidade de realocação!")
        exit()  # Caso não encontre célula livre acima, sai do programa

# -----Termina a realocação da célula caso a pessoa tenha digitado coordenadas em cima do obstáculo --------------------

###############Inicia a numeração das celulas##########################################################################
print("Início do cálculo e preenchimento dos pesos de cada célula ...")
print('   Colocando peso na célula destino, à sua direita, esquerda, acima e abaixo ...')
matriz_celula[c_dest_celula_y][c_dest_celula_x].distancia_para_alvo = 1
preenche_a_direita(c_dest_celula_y, c_dest_celula_x)  # coloco a distancia para o alvo nas celulas a direita
preenche_a_esquerda(c_dest_celula_y, c_dest_celula_x)  # coloco a distancia para o alvo nas celulas a esquerda
preenche_abaixo(c_dest_celula_y, c_dest_celula_x)  # coloco a distancia para o alvo nas celulas acima
preenche_acima(c_dest_celula_y, c_dest_celula_x)  # coloco a distancia para o alvo nas celulas abaixo

# ----Vamos iniciar a preencher as celulas fora da linha da celula destino
print('   Colocando peso nas células a partir da linha e coluna da célula destino ...')
ref_x = c_dest_celula_x  # recebe o valor do eixo x da celula destino
ref_y = c_dest_celula_y  # recebe o valor do eixo y da celula destino
ref_x -= 1  # desloco para esquerda
# Neste while abaixo vamos percorrer as células a esquerda da celula destino e preencher as celulas acima e abaixo delas
while matriz_celula[ref_y][ref_x].obstaculo != 1 and ref_x >= 0:
    if matriz_celula[ref_y][ref_x].obstaculo != 1 and matriz_celula[ref_y][ref_x].distancia_para_alvo != None:
        preenche_acima(ref_y, ref_x)
        preenche_abaixo(ref_y, ref_x)
    ref_x -= 1

# Agora começamos a preencher as demais celulas
print('   Colocando peso nas demais células ...')
print('      ++Esquerda - Direita ...')
aux1_x = 0
while aux1_x <= 29:
    aux1_y = 0
    while aux1_y <= 29:
        if matriz_celula[aux1_y][aux1_x].distancia_para_alvo == None and matriz_celula[aux1_y][
            aux1_x].obstaculo == 0:  # se for uma celula obstaculo pula pra próxima
            distancia_cel, coord_y, coord_x = busca_celula_peso_esquerda(aux1_y, aux1_x)
            if distancia_cel != 1000000:
                preenche_a_direita(coord_y, coord_x)
            else:
                distancia_cel, coord_y, coord_x = busca_celula_peso_direita(aux1_y, aux1_x)
                if distancia_cel != 1000000:
                    preenche_a_esquerda(coord_y, coord_x)
        aux1_y += 1
    aux1_x += 1

print('      ++Acima - Abaixo ...')
aux1_x = 0
while aux1_x <= 29:
    aux1_y = 0
    while aux1_y <= 29:
        if matriz_celula[aux1_y][aux1_x].distancia_para_alvo == None and matriz_celula[aux1_y][
            aux1_x].obstaculo == 0:  # se for uma celula obstaculo pula pra próxima
            distancia_cel, coord_y, coord_x = busca_celula_peso_acima(aux1_y, aux1_x)
            if distancia_cel != 1000000:
                preenche_abaixo(coord_y, coord_x)
            else:
                distancia_cel, coord_y, coord_x = busca_celula_peso_abaixo(aux1_y, aux1_x)
                if distancia_cel != 1000000:
                    preenche_acima(coord_y, coord_x)
        aux1_y += 1
    aux1_x += 1

print('   Fim do cálculo e preenchimento dos pesos das células!')
################### Fim da numeração das celulas #####################################################################

# Apenas para verificar se há alguma celula sem peso
aux1_x = 0
cont = 0
while aux1_x <= 29:
    aux1_y = 0
    while aux1_y <= 29:
        if matriz_celula[aux1_y][aux1_x].distancia_para_alvo == None and matriz_celula[aux1_y][aux1_x].obstaculo == 0:
            cont += 1
        aux1_y += 1
    aux1_x += 1
print('Numero de celulas sem peso: ', cont)

# Vamos iniciar o determinação da posição original do robo
print('Iniciando o robô!')

rospy.init_node('trab_questao4', anonymous=False)

# Cria um tópico para ler os dados de odometria
rospy.Subscriber('/odom', Odometry, odometry_callback)

# Cria um tópico para ler os dados do scan
rospy.Subscriber('/base_scan', LaserScan, laser_callback)

# Cria um tópico para publicarmos a velocidade do robô
pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

# Enquanto estiver rodando ele vai publicar a informação de velociade
r = rospy.Rate(5)  # isto é um sleep para aliviar o processamento

# Criaremos uma variavel (velocity) que será a msg
# a ser publicada. Como vamos publicar ela em cmd_vel,
# esta tem que ser do tipo Twist.
velocity = Twist()  # isto é como se fosse uma declaração

################Devemos determinar uma matriz que indicar o caminho até chegar ao alvo################################
x = 250.0  # odometry.pose.pose.position.x
y = -250.0  # odometry.pose.pose.position.y
matriz_caminho = crie_matriz(100, 2)  # esta matriz vai armazenar a sequencia de celulas para o robo passar
# Calculando coordenadas do robo para saber em qual celula ele está
coord_pixel_x = x + 300  # coordenada x em pixel
coord_pixel_y = -y + 300  # coordenada y em pixel
aux1_x = 0
while aux1_x <= 29:
    aux1_y = 0
    while aux1_y <= 29:
        if (matriz_celula[aux1_y][aux1_x].coord_x - 10) <= (coord_pixel_x) and (coord_pixel_x) <= (
                matriz_celula[aux1_y][aux1_x].coord_x + 9):
            if (matriz_celula[aux1_y][aux1_x].coord_y - 10) <= (coord_pixel_y) and (coord_pixel_y) <= (
                    matriz_celula[aux1_y][aux1_x].coord_y + 9):
                coord_y = aux1_y  # indice y da celula onde o robo está
                coord_x = aux1_x  # indice x da celula onde robo está
                aux1_x = 30
                aux1_y = 30
        aux1_y += 1
    aux1_x += 1
print('Posição atual: y= ', y, ' x= ', x)
# Fim do cálculo dos indices da celula onde o robo se encontra

indice_dest_robo_y, indice_dest_robo_x = celula_destino(coord_y, coord_x)  # indices da primeira celula destino
matriz_caminho[0][0] = indice_dest_robo_y
matriz_caminho[0][1] = indice_dest_robo_x
aux1_x = 0
while aux1_x < 99 and not (c_dest_celula_x == indice_dest_robo_x and c_dest_celula_y == indice_dest_robo_y):
    indice_dest_robo_y, indice_dest_robo_x = celula_destino(matriz_caminho[aux1_x][0],
                                                            matriz_caminho[aux1_x][1])  # indices da celula destino
    matriz_caminho[aux1_x + 1][0] = indice_dest_robo_y
    matriz_caminho[aux1_x + 1][1] = indice_dest_robo_x
    aux1_x += 1
################Fim do cálculo da matriz caminho######################################################################

aux2 = 0
erro_y = 0
erro_x = 0
k = 1000  # ganho para calculo de velecidade linear
d = 1.5
while not rospy.is_shutdown():
    orient = odometry.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion([orient.x, orient.y, orient.z, orient.w])
    x0 = odometry.pose.pose.position.x + d * cos(theta)
    y0 = odometry.pose.pose.position.y + d * sin(theta)
    q0 = np.array([x0, y0])
    x = x0  # odometry.pose.pose.position.x
    y = y0  # odometry.pose.pose.position.y
    x_inicial = x0
    y_inicial = y0
    # theta = odometry.pose.pose.orientation.z

    # Calculando coordenadas do robo para saber em qual celula ele está
    coord_pixel_x = x + 300  # coordenada x em pixel
    coord_pixel_y = -y + 300  # coordenada y em pixel
    aux1_x = 0
    while aux1_x <= 29:
        aux1_y = 0
        while aux1_y <= 29:
            if (matriz_celula[aux1_y][aux1_x].coord_x - 10) <= (coord_pixel_x) and (coord_pixel_x) <= (
                    matriz_celula[aux1_y][aux1_x].coord_x + 9):
                if (matriz_celula[aux1_y][aux1_x].coord_y - 10) <= (coord_pixel_y) and (coord_pixel_y) <= (
                        matriz_celula[aux1_y][aux1_x].coord_y + 9):
                    coord_y = aux1_y  # indice y da celula onde o robo está
                    coord_x = aux1_x  # indice x da celula onde robo está
                    aux1_x = 30
                    aux1_y = 30
            aux1_y += 1
        aux1_x += 1

    # Fim do cálculo dos indices da celula onde o robo se encontra

    while aux2 < 99 and not (matriz_caminho[0][0] == 0 and matriz_caminho[0][1] == 0) and (erro_y < 3 and erro_x < 3):
        indice_dest_robo_y = matriz_caminho[aux2][0]  # recebe o indice y da matriz_caminho
        indice_dest_robo_x = matriz_caminho[aux2][1]  # recebe o indice x da matriz_caminho
        yf = 300 - matriz_celula[indice_dest_robo_y][indice_dest_robo_x].coord_y  # coordenada em metros
        xf = matriz_celula[indice_dest_robo_y][indice_dest_robo_x].coord_x - 300  # coordenada em metros
        aux2 += 1
        erro_y = abs(yf - y)
        erro_x = abs(xf - x)

    erro_y = abs(yf - y)
    erro_x = abs(xf - x)

    # yf=-250
    # xf=-250
    # print('Pos. atual:y= ', y, ' x= ', x)
    print('Destino: y= ', yf, '    x= ', xf)
    # print('Celula de destino: y=', indice_dest_robo_y, ' x=', indice_dest_robo_x)
    # print('Erro y: ', erro_y, 'Erro x: ', erro_x)
    # print('Arco tan: ', atan2((yf-y),(xf-x)))
    velocity.linear.x = k * (cos(theta) * (xf - q0[0]) + sin(theta) * (yf - q0[1]))
    velocity.angular.z = k * (-sin(theta) * (xf - q0[0]) / d + (cos(theta) * (yf - q0[1])) / d)

    pub.publish(velocity)
    # print('Vel linear: ', velocity.linear.x, ' Vel ang:', velocity.angular.z)
    r.sleep()
    print('Posição y: ', y_inicial, 'Posição x: ', x_inicial)

print('FIM')
